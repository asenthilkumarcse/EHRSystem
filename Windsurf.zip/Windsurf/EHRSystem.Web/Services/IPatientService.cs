using EHRSystem.Web.Models;

namespace EHRSystem.Web.Services;

public interface IPatientService
{
    Task<IEnumerable<Patient>> GetAllPatientsAsync();
    Task<Patient?> GetPatientByIdAsync(int id);
    Task<Patient> CreatePatientAsync(Patient patient);
    Task UpdatePatientAsync(int id, Patient patient);
    Task DeletePatientAsync(int id);
}
