using EHRSystem.Web.Models;
using System.Text;
using System.Text.Json;

namespace EHRSystem.Web.Services;

public class MedicalRecordService : IMedicalRecordService
{
    private readonly HttpClient _httpClient;
    private readonly JsonSerializerOptions _jsonOptions;

    public MedicalRecordService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _httpClient.BaseAddress = new Uri(configuration["ApiSettings:BaseUrl"] ?? "http://localhost:5000/");
        _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
    }

    public async Task<IEnumerable<MedicalRecord>> GetAllMedicalRecordsAsync()
    {
        var response = await _httpClient.GetAsync("api/medicalrecords");
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<IEnumerable<MedicalRecord>>(content, _jsonOptions) ?? Array.Empty<MedicalRecord>();
    }

    public async Task<MedicalRecord?> GetMedicalRecordByIdAsync(int id)
    {
        var response = await _httpClient.GetAsync($"api/medicalrecords/{id}");
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            return null;
            
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<MedicalRecord>(content, _jsonOptions);
    }

    public async Task<IEnumerable<MedicalRecord>> GetPatientMedicalRecordsAsync(int patientId)
    {
        var response = await _httpClient.GetAsync($"api/medicalrecords/patient/{patientId}");
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<IEnumerable<MedicalRecord>>(content, _jsonOptions) ?? Array.Empty<MedicalRecord>();
    }

    public async Task<MedicalRecord> CreateMedicalRecordAsync(MedicalRecord medicalRecord)
    {
        var content = new StringContent(JsonSerializer.Serialize(medicalRecord), Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync("api/medicalrecords", content);
        response.EnsureSuccessStatusCode();
        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<MedicalRecord>(responseContent, _jsonOptions) ?? 
            throw new InvalidOperationException("Failed to deserialize the created medical record");
    }

    public async Task UpdateMedicalRecordAsync(int id, MedicalRecord medicalRecord)
    {
        var content = new StringContent(JsonSerializer.Serialize(medicalRecord), Encoding.UTF8, "application/json");
        var response = await _httpClient.PutAsync($"api/medicalrecords/{id}", content);
        response.EnsureSuccessStatusCode();
    }

    public async Task DeleteMedicalRecordAsync(int id)
    {
        var response = await _httpClient.DeleteAsync($"api/medicalrecords/{id}");
        response.EnsureSuccessStatusCode();
    }
}
