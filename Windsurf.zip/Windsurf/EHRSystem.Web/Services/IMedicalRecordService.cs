using EHRSystem.Web.Models;

namespace EHRSystem.Web.Services;

public interface IMedicalRecordService
{
    Task<IEnumerable<MedicalRecord>> GetAllMedicalRecordsAsync();
    Task<MedicalRecord?> GetMedicalRecordByIdAsync(int id);
    Task<IEnumerable<MedicalRecord>> GetPatientMedicalRecordsAsync(int patientId);
    Task<MedicalRecord> CreateMedicalRecordAsync(MedicalRecord medicalRecord);
    Task UpdateMedicalRecordAsync(int id, MedicalRecord medicalRecord);
    Task DeleteMedicalRecordAsync(int id);
}
