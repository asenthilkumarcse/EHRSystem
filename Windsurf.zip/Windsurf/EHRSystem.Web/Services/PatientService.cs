using EHRSystem.Web.Models;
using System.Text;
using System.Text.Json;

namespace EHRSystem.Web.Services;

public class PatientService : IPatientService
{
    private readonly HttpClient _httpClient;
    private readonly JsonSerializerOptions _jsonOptions;

    public PatientService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _httpClient.BaseAddress = new Uri(configuration["ApiSettings:BaseUrl"] ?? "http://localhost:5000/");
        _jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
    }

    public async Task<IEnumerable<Patient>> GetAllPatientsAsync()
    {
        var response = await _httpClient.GetAsync("api/patients");
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<IEnumerable<Patient>>(content, _jsonOptions) ?? Array.Empty<Patient>();
    }

    public async Task<Patient?> GetPatientByIdAsync(int id)
    {
        var response = await _httpClient.GetAsync($"api/patients/{id}");
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            return null;
            
        response.EnsureSuccessStatusCode();
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<Patient>(content, _jsonOptions);
    }

    public async Task<Patient> CreatePatientAsync(Patient patient)
    {
        var content = new StringContent(JsonSerializer.Serialize(patient), Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync("api/patients", content);
        response.EnsureSuccessStatusCode();
        var responseContent = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<Patient>(responseContent, _jsonOptions) ?? 
            throw new InvalidOperationException("Failed to deserialize the created patient");
    }

    public async Task UpdatePatientAsync(int id, Patient patient)
    {
        var content = new StringContent(JsonSerializer.Serialize(patient), Encoding.UTF8, "application/json");
        var response = await _httpClient.PutAsync($"api/patients/{id}", content);
        response.EnsureSuccessStatusCode();
    }

    public async Task DeletePatientAsync(int id)
    {
        var response = await _httpClient.DeleteAsync($"api/patients/{id}");
        response.EnsureSuccessStatusCode();
    }
}
