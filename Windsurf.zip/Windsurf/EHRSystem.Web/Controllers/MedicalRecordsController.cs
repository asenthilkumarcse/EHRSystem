using Microsoft.AspNetCore.Mvc;
using EHRSystem.Web.Models;
using EHRSystem.Web.Services;

namespace EHRSystem.Web.Controllers;

public class MedicalRecordsController : Controller
{
    private readonly IMedicalRecordService _medicalRecordService;
    private readonly IPatientService _patientService;

    public MedicalRecordsController(IMedicalRecordService medicalRecordService, IPatientService patientService)
    {
        _medicalRecordService = medicalRecordService;
        _patientService = patientService;
    }

    // GET: MedicalRecords
    public async Task<IActionResult> Index()
    {
        var medicalRecords = await _medicalRecordService.GetAllMedicalRecordsAsync();
        return View(medicalRecords);
    }

    // GET: MedicalRecords/Details/5
    public async Task<IActionResult> Details(int id)
    {
        var medicalRecord = await _medicalRecordService.GetMedicalRecordByIdAsync(id);
        if (medicalRecord == null)
        {
            return NotFound();
        }

        return View(medicalRecord);
    }

    // GET: MedicalRecords/Create
    public async Task<IActionResult> Create(int? patientId)
    {
        if (patientId.HasValue)
        {
            var patient = await _patientService.GetPatientByIdAsync(patientId.Value);
            if (patient != null)
            {
                ViewBag.PatientId = patient.Id;
                ViewBag.PatientName = $"{patient.FirstName} {patient.LastName}";
            }
        }
        return View();
    }

    // POST: MedicalRecords/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(MedicalRecord medicalRecord)
    {
        if (ModelState.IsValid)
        {
            medicalRecord.CreatedAt = DateTime.UtcNow;
            await _medicalRecordService.CreateMedicalRecordAsync(medicalRecord);
            return RedirectToAction("Details", "Patients", new { id = medicalRecord.PatientId });
        }
        return View(medicalRecord);
    }

    // GET: MedicalRecords/Edit/5
    public async Task<IActionResult> Edit(int id)
    {
        var medicalRecord = await _medicalRecordService.GetMedicalRecordByIdAsync(id);
        if (medicalRecord == null)
        {
            return NotFound();
        }
        return View(medicalRecord);
    }

    // POST: MedicalRecords/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, MedicalRecord medicalRecord)
    {
        if (id != medicalRecord.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            medicalRecord.UpdatedAt = DateTime.UtcNow;
            await _medicalRecordService.UpdateMedicalRecordAsync(id, medicalRecord);
            return RedirectToAction("Details", "Patients", new { id = medicalRecord.PatientId });
        }
        return View(medicalRecord);
    }

    // GET: MedicalRecords/Delete/5
    public async Task<IActionResult> Delete(int id)
    {
        var medicalRecord = await _medicalRecordService.GetMedicalRecordByIdAsync(id);
        if (medicalRecord == null)
        {
            return NotFound();
        }

        return View(medicalRecord);
    }

    // POST: MedicalRecords/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var medicalRecord = await _medicalRecordService.GetMedicalRecordByIdAsync(id);
        if (medicalRecord == null)
        {
            return NotFound();
        }

        await _medicalRecordService.DeleteMedicalRecordAsync(id);
        return RedirectToAction("Details", "Patients", new { id = medicalRecord.PatientId });
    }
}
