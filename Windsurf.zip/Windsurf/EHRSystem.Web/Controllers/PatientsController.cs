using Microsoft.AspNetCore.Mvc;
using EHRSystem.Web.Models;
using EHRSystem.Web.Services;

namespace EHRSystem.Web.Controllers;

public class PatientsController : Controller
{
    private readonly IPatientService _patientService;
    private readonly IMedicalRecordService _medicalRecordService;

    public PatientsController(IPatientService patientService, IMedicalRecordService medicalRecordService)
    {
        _patientService = patientService;
        _medicalRecordService = medicalRecordService;
    }

    // GET: Patients
    public async Task<IActionResult> Index()
    {
        var patients = await _patientService.GetAllPatientsAsync();
        return View(patients);
    }

    // GET: Patients/Details/5
    public async Task<IActionResult> Details(int id)
    {
        var patient = await _patientService.GetPatientByIdAsync(id);
        if (patient == null)
        {
            return NotFound();
        }

        var medicalRecords = await _medicalRecordService.GetPatientMedicalRecordsAsync(id);
        ViewBag.MedicalRecords = medicalRecords;

        return View(patient);
    }

    // GET: Patients/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Patients/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Patient patient)
    {
        if (ModelState.IsValid)
        {
            await _patientService.CreatePatientAsync(patient);
            return RedirectToAction(nameof(Index));
        }
        return View(patient);
    }

    // GET: Patients/Edit/5
    public async Task<IActionResult> Edit(int id)
    {
        var patient = await _patientService.GetPatientByIdAsync(id);
        if (patient == null)
        {
            return NotFound();
        }
        return View(patient);
    }

    // POST: Patients/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Patient patient)
    {
        if (id != patient.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            await _patientService.UpdatePatientAsync(id, patient);
            return RedirectToAction(nameof(Index));
        }
        return View(patient);
    }

    // GET: Patients/Delete/5
    public async Task<IActionResult> Delete(int id)
    {
        var patient = await _patientService.GetPatientByIdAsync(id);
        if (patient == null)
        {
            return NotFound();
        }

        return View(patient);
    }

    // POST: Patients/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        await _patientService.DeletePatientAsync(id);
        return RedirectToAction(nameof(Index));
    }
}
