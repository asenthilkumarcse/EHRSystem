using Microsoft.EntityFrameworkCore;
using EHRSystem.API.Models;

namespace EHRSystem.API.Data;

public class EHRDbContext : DbContext
{
    public EHRDbContext(DbContextOptions<EHRDbContext> options) : base(options)
    {
    }

    public DbSet<Patient> Patients { get; set; }
    public DbSet<MedicalRecord> MedicalRecords { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MedicalRecord>()
            .HasOne(m => m.Patient)
            .WithMany()
            .HasForeignKey(m => m.PatientId);
    }
}
