using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EHRSystem.API.Data;
using EHRSystem.API.Models;

namespace EHRSystem.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MedicalRecordsController : ControllerBase
{
    private readonly EHRDbContext _context;

    public MedicalRecordsController(EHRDbContext context)
    {
        _context = context;
    }

    // GET: api/medicalrecords
    [HttpGet]
    public async Task<ActionResult<IEnumerable<MedicalRecord>>> GetMedicalRecords()
    {
        return await _context.MedicalRecords.Include(m => m.Patient).ToListAsync();
    }

    // GET: api/medicalrecords/5
    [HttpGet("{id}")]
    public async Task<ActionResult<MedicalRecord>> GetMedicalRecord(int id)
    {
        var medicalRecord = await _context.MedicalRecords
            .Include(m => m.Patient)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (medicalRecord == null)
        {
            return NotFound();
        }

        return medicalRecord;
    }

    // GET: api/medicalrecords/patient/5
    [HttpGet("patient/{patientId}")]
    public async Task<ActionResult<IEnumerable<MedicalRecord>>> GetPatientMedicalRecords(int patientId)
    {
        return await _context.MedicalRecords
            .Include(m => m.Patient)
            .Where(m => m.PatientId == patientId)
            .ToListAsync();
    }

    // POST: api/medicalrecords
    [HttpPost]
    public async Task<ActionResult<MedicalRecord>> CreateMedicalRecord(MedicalRecord medicalRecord)
    {
        var patient = await _context.Patients.FindAsync(medicalRecord.PatientId);
        if (patient == null)
        {
            return BadRequest("Invalid Patient ID");
        }

        medicalRecord.CreatedAt = DateTime.UtcNow;
        _context.MedicalRecords.Add(medicalRecord);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetMedicalRecord), new { id = medicalRecord.Id }, medicalRecord);
    }

    // PUT: api/medicalrecords/5
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateMedicalRecord(int id, MedicalRecord medicalRecord)
    {
        if (id != medicalRecord.Id)
        {
            return BadRequest();
        }

        medicalRecord.UpdatedAt = DateTime.UtcNow;
        _context.Entry(medicalRecord).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!MedicalRecordExists(id))
            {
                return NotFound();
            }
            throw;
        }

        return NoContent();
    }

    // DELETE: api/medicalrecords/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMedicalRecord(int id)
    {
        var medicalRecord = await _context.MedicalRecords.FindAsync(id);
        if (medicalRecord == null)
        {
            return NotFound();
        }

        _context.MedicalRecords.Remove(medicalRecord);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool MedicalRecordExists(int id)
    {
        return _context.MedicalRecords.Any(e => e.Id == id);
    }
}
